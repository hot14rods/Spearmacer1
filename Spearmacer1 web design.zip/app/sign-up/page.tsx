'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { authClient } from '@/lib/auth-client'

export default function SignUpPage() {
  const router = useRouter()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [confirmReveal, setConfirmReveal] = useState(false)
  const [accountCreated, setAccountCreated] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    const hasPasswordRequirements = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[^A-Za-z\s]).{8,}$/.test(password)
    if (!hasPasswordRequirements) {
      setError('Password must be at least 8 characters and include a lowercase letter, an uppercase letter, and a special character.')
      return
    }
    setLoading(true)
    const result = await authClient.signUp.email({ name, email: email.trim(), password })
    setLoading(false)
    if (result.error) {
      setError('Could not create the account. Use a valid email and a stronger password.')
      return
    }
    setAccountCreated(true)
    window.setTimeout(() => { router.push('/'); router.refresh() }, 3000)
  }

  return <main className="grid min-h-screen place-items-center bg-[#101012] px-5 text-white">{accountCreated && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 px-5 backdrop-blur-sm" role="status" aria-live="polite"><div className="w-full max-w-sm rounded-3xl border border-[#59e7a2]/30 bg-[#19191e] p-8 text-center shadow-2xl"><div className="mx-auto grid size-16 place-items-center rounded-full bg-[#59e7a2]/15 text-4xl font-black text-[#59e7a2]">✓</div><h2 className="mt-5 text-2xl font-black">Account created successfully</h2><p className="mt-2 text-sm text-white/55">Taking you to the home screen...</p></div></div>}<form onSubmit={submit} className="flex w-full max-w-md flex-col gap-5 rounded-3xl border border-white/10 bg-white/[0.05] p-8 shadow-2xl"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">Join the community</p><h1 className="mt-2 text-3xl font-black">Create an account</h1></div><label className="flex flex-col gap-2 text-sm font-semibold">Display name<input required value={name} onChange={(event) => setName(event.target.value)} className="h-11 rounded-xl border border-white/10 bg-black/20 px-3 font-normal outline-none focus:border-[#35d7ff]/60" /></label><label className="flex flex-col gap-2 text-sm font-semibold">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="h-11 rounded-xl border border-white/10 bg-black/20 px-3 font-normal outline-none focus:border-[#35d7ff]/60" /></label><label className="flex flex-col gap-2 text-sm font-semibold">Password<div className="relative"><input required minLength={8} type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 pr-12 font-normal outline-none focus:border-[#35d7ff]/60" /><button type="button" aria-label="Reveal password" onClick={() => setConfirmReveal(true)} className="absolute right-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-lg text-white/50 transition hover:bg-white/10 hover:text-white">{showPassword ? '◉' : '◌'}</button></div></label>{error && <p role="alert" className="text-sm text-[#ff8098]">{error}</p>}{confirmReveal && <div role="dialog" aria-modal="true" aria-labelledby="reveal-title" className="fixed inset-0 z-50 grid place-items-center bg-black/75 px-5"><div className="w-full max-w-sm rounded-2xl border border-white/15 bg-[#19191d] p-6 shadow-2xl"><h2 id="reveal-title" className="text-lg font-bold">Reveal password?</h2><p className="mt-2 text-sm leading-6 text-white/60">Are you sure you want to reveal your password? If you are streaming or screensharing, do not show it.</p><div className="mt-5 flex justify-end gap-3"><button type="button" onClick={() => setConfirmReveal(false)} className="rounded-xl border border-white/10 px-4 py-2 text-sm font-semibold text-white/70 hover:bg-white/10">Cancel</button><button type="button" onClick={() => { setShowPassword(true); setConfirmReveal(false) }} className="rounded-xl bg-[#934cff] px-4 py-2 text-sm font-bold hover:bg-[#a965ff]">Reveal password</button></div></div></div>}<button disabled={loading} className="h-11 rounded-xl bg-[#934cff] font-bold transition hover:bg-[#a965ff] disabled:opacity-60">{loading ? 'Creating…' : 'Create account'}</button><p className="text-center text-sm text-white/50">Already have an account? <Link className="font-semibold text-[#8edfff] hover:text-white" href="/sign-in">Sign in</Link></p></form></main>
}
