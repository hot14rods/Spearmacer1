'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Blocks, Download, Upload } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

type Schematic = { url: string; pathname: string; uploadedAt: string; size: number }

export default function SchematicsPage() {
  const [activeTab, setActiveTab] = useState<'upload' | 'browse'>('upload')
  const [file, setFile] = useState<File | null>(null)
  const [photo, setPhoto] = useState<File | null>(null)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const [uploadController, setUploadController] = useState<AbortController | null>(null)
  const [schematics, setSchematics] = useState<Schematic[]>([])
  const { data: session } = authClient.useSession()

  useEffect(() => {
    if (activeTab !== 'browse') return
    fetch('/api/schematics').then((response) => response.json()).then((data) => setSchematics(data.schematics ?? []))
  }, [activeTab])

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!session?.user) return setStatus('Sign in to upload a schematic.')
    if (!file) return setStatus('Choose a .litematic file first.')
    setBusy(true); setStatus('')
    const data = new FormData(); data.append('file', file); if (photo) data.append('photo', photo)
    const controller = new AbortController(); setUploadController(controller)
    let response: Response
    try { response = await fetch('/api/schematics', { method: 'POST', body: data, signal: controller.signal }) } catch (error) { if (error instanceof DOMException && error.name === 'AbortError') { setBusy(false); setStatus('Upload canceled.'); setUploadController(null); return } throw error }
    const result = await response.json(); setUploadController(null)
    setBusy(false); setStatus(response.ok ? 'Your schematic was uploaded successfully.' : result.error ?? 'Upload failed.')
    if (response.ok) { setFile(null); setActiveTab('browse') }
  }

  return <main className="min-h-screen bg-[#041321] px-5 py-8 text-[#f5f5f7] sm:px-8"><div className="mx-auto max-w-3xl"><Link href="/" className="inline-flex items-center gap-2 text-sm text-white/55 hover:text-white"><ArrowLeft className="size-4" /> Back home</Link><section className="mt-12 rounded-3xl border border-white/10 bg-white/[0.045] p-7 sm:p-10"><div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-2xl bg-[#9b5cff]/15"><Blocks className="size-6 text-[#c39aff]" /></span><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#c39aff]">Kingdom blueprints</p><h1 className="mt-1 text-3xl font-black">Schematics</h1></div></div><p className="mt-5 leading-7 text-white/55">Share .litematic schematics so other builders can bring your designs into the kingdom.</p><div className="mt-8 grid grid-cols-2 rounded-xl border border-white/10 bg-black/20 p-1" role="tablist"><button type="button" role="tab" aria-selected={activeTab === 'upload'} onClick={() => setActiveTab('upload')} className={`rounded-lg px-4 py-3 text-sm font-bold transition ${activeTab === 'upload' ? 'bg-[#9b5cff] text-white' : 'text-white/50 hover:text-white'}`}><Upload className="mr-2 inline size-4" />Upload a schematic</button><button type="button" role="tab" aria-selected={activeTab === 'browse'} onClick={() => setActiveTab('browse')} className={`rounded-lg px-4 py-3 text-sm font-bold transition ${activeTab === 'browse' ? 'bg-[#9b5cff] text-white' : 'text-white/50 hover:text-white'}`}>Browse schematics</button></div>{activeTab === 'upload' ? <form onSubmit={submit} className="mt-8"><label htmlFor="schematic-file" className="flex min-h-48 cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-white/20 bg-black/20 text-center hover:border-[#9b5cff]/60"><Upload className="size-8 text-[#c39aff]" /><span className="mt-3 font-bold">{file ? file.name : 'Choose a .litematic file'}</span><span className="mt-1 text-xs text-white/40">Litematica schematic · 50 MB maximum</span><input id="schematic-file" type="file" accept=".litematic,application/octet-stream" className="sr-only" onChange={(event) => setFile(event.target.files?.[0] ?? null)} /><input id="schematic-photo" type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" onChange={(event) => setPhoto(event.target.files?.[0] ?? null)} /><span className="mt-2 text-xs text-white/40">Optional preview photo: {photo ? photo.name : 'PNG, JPEG, or WebP up to 10 MB'}</span></label><button type="submit" disabled={busy} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-xl bg-[#9b5cff] font-bold text-white disabled:opacity-50">{busy ? 'Uploading...' : 'Upload schematic'}</button>{status && <p className="mt-5 text-sm text-white/70" role="status">{status}</p>}{busy && <button type="button" onClick={() => uploadController?.abort()} className="ml-3 rounded-xl border border-[#ff8098]/30 px-5 py-3 text-sm font-bold text-[#ff9aae]">Cancel upload</button>}</form> : <div className="mt-8 space-y-3">{schematics.length === 0 ? <p className="rounded-2xl border border-dashed border-white/15 p-10 text-center text-sm text-white/45">No schematics have been uploaded yet.</p> : schematics.map((schematic) => <article key={schematic.pathname} className="flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-black/20 p-4"><div><h2 className="font-bold">{schematic.pathname.split('/').pop()?.replace(/^\d+-/, '')}</h2><p className="mt-1 text-xs text-white/40">{(schematic.size / 1024 / 1024).toFixed(1)} MB · {new Date(schematic.uploadedAt).toLocaleDateString()}</p></div><a href={`/api/schematics/download?url=${encodeURIComponent(schematic.url)}`} className="inline-flex items-center gap-2 rounded-xl border border-[#9b5cff]/30 px-3 py-2 text-xs font-bold text-[#c39aff] hover:bg-[#9b5cff]/10"><Download className="size-4" /> Download</a></article>)}</div>}</section></div></main>
}
