'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { authClient } from '@/lib/auth-client'
import { Eye, EyeOff } from 'lucide-react'

export default function SignInPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setLoading(true)
    const result = await authClient.signIn.email({ email, password })
    setLoading(false)
    if (result.error) {
      setError('Sign-in failed. Check your email and password and try again.')
      return
    }
    router.push('/')
    router.refresh()
  }

  return <main className="grid min-h-screen place-items-center bg-[#101012] px-5 text-white"><form onSubmit={submit} className="flex w-full max-w-md flex-col gap-5 rounded-3xl border border-white/10 bg-white/[0.05] p-8 shadow-2xl"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">Spearmacer1 community</p><h1 className="mt-2 text-3xl font-black">Sign in to your account</h1><p className="mt-2 text-sm text-white/50">Guests can browse freely. Accounts unlock community features.</p></div><label className="flex flex-col gap-2 text-sm font-semibold">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="h-11 rounded-xl border border-white/10 bg-black/20 px-3 font-normal outline-none focus:border-[#35d7ff]/60" /></label><label className="flex flex-col gap-2 text-sm font-semibold">Password<span className="relative"><input required type={showPassword ? 'text' : 'password'} value={password} onChange={(event) => setPassword(event.target.value)} className="h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 pr-11 font-normal outline-none focus:border-[#35d7ff]/60" /><button type="button" onClick={() => setShowPassword((visible) => !visible)} aria-label={showPassword ? 'Hide password' : 'Show password'} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/50 transition hover:text-white"><span className="sr-only">{showPassword ? 'Hide password' : 'Show password'}</span>{showPassword ? <EyeOff aria-hidden="true" /> : <Eye aria-hidden="true" />}</button></span></label>{error && <p role="alert" className="text-sm text-[#ff8098]">{error}</p>}<button disabled={loading} className="h-11 rounded-xl bg-[#934cff] font-bold transition hover:bg-[#a965ff] disabled:opacity-60">{loading ? 'Signing in…' : 'Sign in'}</button><p className="text-center text-sm text-white/50">Need an account? <Link className="font-semibold text-[#8edfff] hover:text-white" href="/sign-up">Create one</Link></p><Link className="text-center text-sm text-white/40 hover:text-white" href="/">Continue as guest</Link></form></main>
}
