import { del, list, put } from '@vercel/blob'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

const MAX_FILE_SIZE = 10 * 1024 * 1024
const allowedTypes = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm', 'application/pdf'])
const contentTypes: Record<string, string> = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', mp4: 'video/mp4', webm: 'video/webm', txt: 'text/plain', pdf: 'application/pdf' }
function getContentType(pathname: string) { return contentTypes[pathname.split('.').pop()?.toLowerCase() ?? ''] ?? 'application/octet-stream' }

export async function GET() {
  try {
    const { blobs } = await list({ prefix: 'fan-art/' })
    return NextResponse.json({ files: blobs.map((blob) => ({ url: blob.url, pathname: blob.pathname, uploadedAt: blob.uploadedAt.toISOString(), contentType: getContentType(blob.pathname) })) })
  } catch {
    return NextResponse.json({ error: 'Unable to load the fan gallery.' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await auth.api.getSession({ headers: await headers() })
    if (!session?.user) return NextResponse.json({ error: 'Sign in to submit fan art.' }, { status: 401 })
    const formData = await request.formData()
    const files = formData.getAll('files').filter((value): value is File => value instanceof File)
    const videoUrl = String(formData.get('videoUrl') ?? '').trim()
    if (!files.some((file) => file.type.startsWith('image/'))) return NextResponse.json({ error: 'Include at least one photo with your submission.' }, { status: 400 })
    if (videoUrl) {
      try { const parsed = new URL(videoUrl); if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error() } catch { return NextResponse.json({ error: 'Enter a valid video URL.' }, { status: 400 }) }
    }
    if (files.length > 10) return NextResponse.json({ error: 'Choose 10 files or fewer at a time.' }, { status: 400 })
    for (const file of files) {
      if (!allowedTypes.has(file.type) || file.size > MAX_FILE_SIZE) return NextResponse.json({ error: 'Use supported files up to 10 MB each.' }, { status: 400 })
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-120)
      await put(`fan-art/${session.user.id}/${Date.now()}-${safeName}`, file, { access: 'public', addRandomSuffix: false })
    }
    if (videoUrl) await put(`fan-art/${session.user.id}/${Date.now()}-video-link.txt`, videoUrl, { access: 'public', contentType: 'text/plain', addRandomSuffix: false })
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Upload failed. Please try again.' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Sign in to delete fan art.' }, { status: 401 })
  const { pathname } = await request.json()
  if (typeof pathname !== 'string' || !pathname.startsWith(`fan-art/${session.user.id}/`)) return NextResponse.json({ error: 'You can only delete your own fan art.' }, { status: 403 })
  await del(pathname)
  return NextResponse.json({ success: true })
}
