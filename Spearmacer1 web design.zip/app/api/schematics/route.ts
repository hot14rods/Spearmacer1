import { del, list, put } from '@vercel/blob'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

const MAX_SIZE = 50 * 1024 * 1024
export async function GET() {
  const { blobs } = await list({ prefix: 'schematics/' })
  return NextResponse.json({ schematics: blobs.map((blob) => ({ url: `/api/schematics/download?url=${encodeURIComponent(blob.url)}`, pathname: blob.pathname, uploadedAt: blob.uploadedAt.toISOString(), size: blob.size })) })
}
export async function DELETE(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() }); const body = await request.json().catch(() => null)
  if (!session?.user || typeof body?.pathname !== 'string' || !body.pathname.startsWith(`schematics/${session.user.id}/`)) return NextResponse.json({ error: 'Not authorized.' }, { status: 403 })
  await del(body.pathname); return NextResponse.json({ success: true })
}
export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Sign in to upload a schematic.' }, { status: 401 })
  const formData = await request.formData()
  const file = formData.get('file')
  const photo = formData.get('photo')
  if (!(file instanceof File) || !file.name.toLowerCase().endsWith('.litematic') || file.size > MAX_SIZE) return NextResponse.json({ error: 'Choose a .litematic file up to 50 MB.' }, { status: 400 })
  if (photo instanceof File && (!['image/jpeg', 'image/png', 'image/webp'].includes(photo.type) || photo.size > 10 * 1024 * 1024)) return NextResponse.json({ error: 'The preview photo must be PNG, JPEG, or WebP up to 10 MB.' }, { status: 400 })
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-120)
  const uploadId = Date.now()
  await put(`schematics/${session.user.id}/${uploadId}-${safeName}`, file, { access: 'public', addRandomSuffix: false, contentType: 'application/octet-stream' })
  if (photo instanceof File) { const photoName = photo.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-120); await put(`schematics/${session.user.id}/${uploadId}-preview-${photoName}`, photo, { access: 'public', addRandomSuffix: false, contentType: photo.type }) }
  return NextResponse.json({ success: true })
}
