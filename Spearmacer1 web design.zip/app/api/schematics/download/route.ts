import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  const url = new URL(request.url).searchParams.get('url')
  if (!url) return NextResponse.json({ error: 'Download URL is required.' }, { status: 400 })
  let blobUrl: URL
  try { blobUrl = new URL(url) } catch { return NextResponse.json({ error: 'Invalid download URL.' }, { status: 400 }) }
  if (!blobUrl.hostname.endsWith('.public.blob.vercel-storage.com')) return NextResponse.json({ error: 'Invalid download host.' }, { status: 400 })
  const response = await fetch(blobUrl)
  if (!response.ok) return NextResponse.json({ error: 'Schematic is unavailable.' }, { status: response.status })
  return new NextResponse(await response.arrayBuffer(), { headers: { 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="${blobUrl.pathname.split('/').pop() ?? 'schematic.litematic'}"`, 'Cache-Control': 'private, max-age=60' } })
}
