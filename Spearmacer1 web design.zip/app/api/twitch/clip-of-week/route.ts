import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { getTokenResponse, UserAuthorizationRequiredError } from '@vercel/connect'
import { auth } from '@/lib/auth'

const CONNECTOR_UID = 'scl_HPDPApjhsc7vNN4acKRy6g'

export async function GET() {
  try {
    const tokenResponse = await getTokenResponse(CONNECTOR_UID, {
      subject: { type: 'app' },
      scopes: [],
    })
    const token = tokenResponse.token
    const clientId = process.env.TWITCH_CLIENT_ID ?? String(tokenResponse.metadata?.client_id ?? tokenResponse.claims?.client_id ?? '')
    if (!clientId) return NextResponse.json({ error: 'Twitch client identity unavailable' }, { status: 503 })

    const headersInit = { Authorization: `Bearer ${token}`, 'Client-Id': clientId }
    const broadcasterResponse = await fetch('https://api.twitch.tv/helix/users?login=ryderhotrodlive', { headers: headersInit, next: { revalidate: 900 } })
    if (!broadcasterResponse.ok) return NextResponse.json({ error: 'Unable to read Twitch channel' }, { status: 502 })
    const broadcaster = (await broadcasterResponse.json()).data?.[0]
    if (!broadcaster) return NextResponse.json({ error: 'Twitch channel not found' }, { status: 404 })

    const clipsResponse = await fetch(`https://api.twitch.tv/helix/clips?broadcaster_id=${encodeURIComponent(broadcaster.id)}&first=100`, { headers: headersInit, next: { revalidate: 900 } })
    if (!clipsResponse.ok) return NextResponse.json({ error: 'Unable to read Twitch clips' }, { status: 502 })
    const clips = (await clipsResponse.json()).data ?? []
    const clip = clips.sort((a: { view_count: number }, b: { view_count: number }) => b.view_count - a.view_count)[0]
    if (!clip) return NextResponse.json({ clip: null })
    return NextResponse.json({ clip: { title: clip.title, creator: clip.creator_name, views: clip.view_count, url: clip.url, thumbnail: clip.thumbnail_url } })
  } catch (error) {
    if (error instanceof UserAuthorizationRequiredError) return NextResponse.json({ error: 'Twitch authorization required' }, { status: 403 })
    console.error('[v0] Twitch clip lookup failed', error)
    return NextResponse.json({ error: 'Unable to load Twitch clips' }, { status: 502 })
  }
}
