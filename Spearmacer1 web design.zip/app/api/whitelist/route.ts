import { randomUUID } from 'node:crypto'
import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'

const OWNER_EMAIL = 'hot14rods@gmail.com'

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })

  const body = await request.json().catch(() => null)
  const minecraftUsername = typeof body?.minecraftUsername === 'string' ? body.minecraftUsername.trim() : ''
  if (!/^[A-Za-z0-9_]{3,16}$/.test(minecraftUsername)) {
    return NextResponse.json({ error: 'Enter a valid Minecraft username.' }, { status: 400 })
  }

  await db.query('INSERT INTO "whitelistRequest" ("id", "minecraftUsername", "userId") VALUES ($1, $2, $3)', [randomUUID(), minecraftUsername, session.user.id])
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user || session.user.email !== OWNER_EMAIL) return NextResponse.json({ error: 'Owner access required.' }, { status: 403 })
  const body = await request.json().catch(() => null)
  if (typeof body?.id !== 'string') return NextResponse.json({ error: 'Request id required.' }, { status: 400 })
  await db.query('DELETE FROM "whitelistRequest" WHERE "id" = $1', [body.id])
  return NextResponse.json({ success: true })
}

export async function GET() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user || session.user.email !== OWNER_EMAIL) {
    return NextResponse.json({ error: 'Owner access required.' }, { status: 403 })
  }

  const result = await db.query('SELECT "id", "minecraftUsername", "createdAt" FROM "whitelistRequest" ORDER BY "createdAt" DESC')
  return NextResponse.json({ requests: result.rows })
}
