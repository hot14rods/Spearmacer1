import { del, list, put } from '@vercel/blob'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

const MAX_SIZE = 500 * 1024 * 1024
export async function GET() {
  const { blobs } = await list({ prefix: 'clips/' })
  return NextResponse.json({ clips: blobs.map((blob) => ({ url: blob.url, pathname: blob.pathname, uploadedAt: blob.uploadedAt.toISOString(), size: blob.size })) })
}
export async function DELETE(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() }); const body = await request.json().catch(() => null)
  if (!session?.user || typeof body?.pathname !== 'string' || !body.pathname.startsWith(`clips/${session.user.id}/`)) return NextResponse.json({ error: 'Not authorized.' }, { status: 403 })
  await del(body.pathname); return NextResponse.json({ success: true })
}
export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Sign in to post a clip.' }, { status: 401 })
  const formData = await request.formData()
  const file = formData.get('file')
  if (!(file instanceof File) || !['video/mp4', 'video/webm'].includes(file.type) || file.size > MAX_SIZE) return NextResponse.json({ error: 'Use an MP4 or WEBM clip up to 500 MB. There is no video length limit.' }, { status: 400 })
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(-120)
  await put(`clips/${session.user.id}/${Date.now()}-${safeName}`, file, { access: 'public', addRandomSuffix: false })
  return NextResponse.json({ success: true })
}
