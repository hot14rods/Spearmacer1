import { auth } from '@/lib/auth'
import { Pool } from 'pg'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

const pool = new Pool({ connectionString: process.env.DATABASE_URL })
const ownerEmail = 'hot14rods@gmail.com'
const platforms = ['offline', 'youtube', 'twitch', 'multistream'] as const

type Platform = (typeof platforms)[number]

export async function GET() {
  const result = await pool.query<{ platform: Platform }>('SELECT platform FROM site_status WHERE id = 1')
  return NextResponse.json({ platform: result.rows[0]?.platform ?? 'offline' })
}

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user?.email !== ownerEmail) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const body = await request.json().catch(() => null) as { platform?: string } | null
  if (!body?.platform || !platforms.includes(body.platform as Platform)) {
    return NextResponse.json({ error: 'Invalid platform' }, { status: 400 })
  }

  await pool.query(
    'INSERT INTO site_status (id, platform, updated_at) VALUES (1, $1, now()) ON CONFLICT (id) DO UPDATE SET platform = EXCLUDED.platform, updated_at = now()',
    [body.platform],
  )

  return NextResponse.json({ platform: body.platform })
}
