import { auth, pool } from '@/lib/auth'
import crypto from 'node:crypto'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'

export async function POST() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const accountResult = await client.query('SELECT "password" FROM "account" WHERE "userId" = $1 AND "providerId" = \'credential\' LIMIT 1', [session.user.id])
    await client.query('INSERT INTO "accountDeletionBackup" ("id", "userId", "email", "name", "passwordHash") VALUES ($1, $2, $3, $4, $5)', [crypto.randomUUID(), session.user.id, session.user.email, session.user.name, accountResult.rows[0]?.password ?? null])
    await client.query('DELETE FROM "session" WHERE "userId" = $1', [session.user.id])
    await client.query('DELETE FROM "account" WHERE "userId" = $1', [session.user.id])
    await client.query('DELETE FROM "verification" WHERE "identifier" = $1', [session.user.email])
    await client.query('DELETE FROM "whitelistRequest" WHERE "userId" = $1', [session.user.id])
    await client.query('DELETE FROM "user" WHERE "id" = $1', [session.user.id])
    await client.query('COMMIT')
    const response = NextResponse.json({ success: true })
    response.cookies.delete('better-auth.session_token')
    return response
  } catch (error) {
    await client.query('ROLLBACK')
    console.error('[v0] Account deletion failed:', error)
    return NextResponse.json({ error: 'Account deletion failed.' }, { status: 500 })
  } finally {
    client.release()
  }
}
