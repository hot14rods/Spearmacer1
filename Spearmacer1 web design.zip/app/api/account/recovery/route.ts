import { auth, pool } from '@/lib/auth'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import { randomUUID } from 'node:crypto'

const OWNER_EMAIL = 'hot14rods@gmail.com'

async function requireOwner() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user || session.user.email !== OWNER_EMAIL) return null
  return session
}

export async function GET() {
  if (!await requireOwner()) return NextResponse.json({ error: 'Owner authorization required.' }, { status: 403 })
  const result = await pool.query('SELECT "id", "email", "name", "deletedAt" FROM "accountDeletionBackup" WHERE "restoredAt" IS NULL ORDER BY "deletedAt" DESC')
  return NextResponse.json({ backups: result.rows })
}

export async function POST(request: Request) {
  if (!await requireOwner()) return NextResponse.json({ error: 'Owner authorization required.' }, { status: 403 })
  const { backupId } = await request.json()
  if (typeof backupId !== 'string') return NextResponse.json({ error: 'Invalid backup.' }, { status: 400 })

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const backupResult = await client.query('SELECT "userId", "email", "name", "passwordHash" FROM "accountDeletionBackup" WHERE "id" = $1 AND "restoredAt" IS NULL FOR UPDATE', [backupId])
    const backup = backupResult.rows[0]
    if (!backup) { await client.query('ROLLBACK'); return NextResponse.json({ error: 'Backup not found.' }, { status: 404 }) }
    const userId = backup.userId
    await client.query('INSERT INTO "user" ("id", "name", "email", "emailVerified", "createdAt", "updatedAt") VALUES ($1, $2, $3, false, now(), now())', [userId, backup.name, backup.email])
    if (backup.passwordHash) await client.query('INSERT INTO "account" ("id", "accountId", "providerId", "userId", "password", "createdAt", "updatedAt") VALUES ($1, $2, \'credential\', $3, $4, now(), now())', [randomUUID(), backup.email, userId, backup.passwordHash])
    await client.query('UPDATE "accountDeletionBackup" SET "restoredAt" = now() WHERE "id" = $1', [backupId])
    await client.query('COMMIT')
    return NextResponse.json({ success: true })
  } catch (error) {
    await client.query('ROLLBACK')
    console.error('[v0] Account recovery failed:', error)
    return NextResponse.json({ error: 'Account recovery failed.' }, { status: 500 })
  } finally { client.release() }
}
