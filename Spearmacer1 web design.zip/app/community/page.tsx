import Link from 'next/link'
import { ArrowLeft, Users } from 'lucide-react'
import { pool } from '@/lib/auth'

export const dynamic = 'force-dynamic'

type CommunityMember = {
  id: string
  name: string | null
  email: string
}

async function getCommunityMembers(): Promise<CommunityMember[]> {
  const result = await pool.query<CommunityMember>(
    'SELECT "id", "name", "email" FROM "user" ORDER BY "createdAt" ASC',
  )
  return result.rows
}

export default async function CommunityPage() {
  const members = await getCommunityMembers()

  return (
    <main className="min-h-screen bg-[#0b0d14] px-5 py-8 text-white sm:px-8">
      <div className="mx-auto max-w-5xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-white/55 transition hover:text-white">
          <ArrowLeft className="size-4" /> Back home
        </Link>

        <header className="mt-16 max-w-2xl">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">Stay connected</p>
          <h1 className="mt-3 text-5xl font-black tracking-[-.05em] sm:text-7xl">Find your people.</h1>
          <p className="mt-6 text-base leading-7 text-white/55 sm:text-lg">
            Follow Twitch or subscribe on YouTube to join the community. Updates daily.
          </p>
        </header>

        <section className="mt-14 rounded-3xl border border-white/10 bg-white/[0.035] p-6 sm:p-8" aria-labelledby="members-heading">
          <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-5">
            <div>
              <h2 id="members-heading" className="text-2xl font-black tracking-tight">Community members</h2>
              <p className="mt-1 text-sm text-white/45">Everyone who has joined the site.</p>
            </div>
            <div className="flex items-center gap-2 rounded-full border border-[#35d7ff]/20 bg-[#35d7ff]/10 px-3 py-1.5 text-sm font-bold text-[#8beaff]">
              <Users className="size-4" /> {members.length}
            </div>
          </div>

          {members.length > 0 ? (
            <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {members.map((member) => (
                <li key={member.id} className="rounded-2xl border border-white/10 bg-black/15 px-4 py-4">
                  <p className="font-bold">{member.name || member.email.split('@')[0]}</p>
                  <p className="mt-1 text-xs text-white/40">Joined community</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="py-12 text-center text-white/45">Be the first to join the community.</p>
          )}
        </section>
      </div>
    </main>
  )
}
