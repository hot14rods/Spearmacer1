'use client'

import useSWR from 'swr'
import Link from 'next/link'
import { ArrowLeft, FileText, Image as ImageIcon, Trash2, Upload } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

type GalleryFile = { url: string; pathname: string; uploadedAt: string; contentType?: string }
const fetcher = (url: string) => fetch(url).then((response) => response.json())

export default function FanGalleryPage() {
  const { data, isLoading, mutate } = useSWR<{ files?: GalleryFile[] }>('/api/fan-art', fetcher)
  const { data: session } = authClient.useSession()
  const files = data?.files ?? []

  async function deleteFile(pathname: string) {
    if (!window.confirm('Delete this fan art? This cannot be undone.')) return
    const response = await fetch('/api/fan-art', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pathname }) })
    if (response.ok) await mutate()
  }

  return <main className="min-h-screen bg-[#101012] px-5 py-8 text-[#f5f5f7] sm:px-8 lg:px-10"><div className="mx-auto max-w-6xl"><div className="flex flex-wrap items-center justify-between gap-4"><Link href="/" className="inline-flex items-center gap-2 text-sm text-white/55 transition hover:text-white"><ArrowLeft className="size-4" /> Back home</Link><Link href="/fan-art/submit" className="inline-flex items-center gap-2 rounded-xl bg-[#934cff] px-4 py-2.5 text-sm font-bold transition hover:bg-[#a965ff]"><Upload className="size-4" /> Submit fan art</Link></div><div className="mt-12"><p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">From the community</p><h1 className="mt-2 text-4xl font-black tracking-tight sm:text-5xl">Fan gallery.</h1><p className="mt-4 max-w-xl text-white/55">Photos, videos, and links shared by the Spearmacer1 community.</p></div>{isLoading ? <p className="mt-12 text-sm text-white/45">Loading the gallery…</p> : files.length === 0 ? <div className="mt-12 rounded-3xl border border-dashed border-white/15 bg-white/[0.03] p-12 text-center"><ImageIcon className="mx-auto size-10 text-[#b98aff]" /><h2 className="mt-4 text-xl font-bold">The gallery is waiting for you.</h2><p className="mt-2 text-sm text-white/45">Be the first to upload fan art.</p><Link href="/fan-art/submit" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#934cff] px-5 py-3 text-sm font-bold transition hover:bg-[#a965ff]"><Upload className="size-4" /> Be the first to upload fan art</Link></div> : <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{files.map((file) => <article key={file.pathname} className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.045]"><div className="flex aspect-[4/3] items-center justify-center bg-black/20">{file.contentType?.startsWith('image/') ? <img src={file.url} alt="Community fan art" className="size-full object-cover" /> : file.contentType?.startsWith('video/') ? <video src={file.url} controls className="size-full object-cover" aria-label="Community fan video" /> : <a href={file.url} target="_blank" rel="noreferrer" className="p-5 text-center text-sm text-[#8edfff] underline"><FileText className="mx-auto mb-2 size-8" /> Open shared video link</a>}</div><div className="flex items-center justify-between gap-3 px-4 py-3"><p className="text-xs text-white/50">Uploaded community fan art</p>{session?.user && file.pathname.startsWith(`fan-art/${session.user.id}/`) && <button type="button" onClick={() => deleteFile(file.pathname)} className="inline-flex items-center gap-1.5 rounded-lg border border-[#ff5577]/25 bg-[#ff5577]/10 px-2.5 py-1.5 text-xs font-semibold text-[#ff9aae] transition hover:bg-[#ff5577]/20"><Trash2 className="size-3.5" /> Delete</button>}</div></article>)}</div>}</div></main>
}
