'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Check, FileUp, ImagePlus, Link2, Upload } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

export default function SubmitFanArtPage() {
  const [files, setFiles] = useState<File[]>([])
  const [videoUrl, setVideoUrl] = useState('')
  const [status, setStatus] = useState('')
  const [isUploading, setIsUploading] = useState(false)
  const { data: session, isPending } = authClient.useSession()

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!session?.user) return setStatus('Sign in to submit fan art.')
    if (!files.some((file) => file.type.startsWith('image/'))) return setStatus('Include at least one photo with your submission.')
    setIsUploading(true)
    setStatus('')
    const formData = new FormData()
    files.forEach((file) => formData.append('files', file))
    if (videoUrl.trim()) formData.append('videoUrl', videoUrl.trim())
    const response = await fetch('/api/fan-art', { method: 'POST', body: formData })
    const result = await response.json()
    setIsUploading(false)
    if (!response.ok) return setStatus(result.error ?? 'Upload failed.')
    setStatus('Your fan art is now in the gallery.')
    setFiles([])
    setVideoUrl('')
  }

  return <main className="min-h-screen bg-[#101012] px-5 py-8 text-[#f5f5f7] sm:px-8 lg:px-10"><div className="mx-auto max-w-3xl"><Link href="/fan-art" className="inline-flex items-center gap-2 text-sm text-white/55 transition hover:text-white"><ArrowLeft className="size-4" /> Back to gallery</Link><div className="mt-12 rounded-3xl border border-white/10 bg-white/[0.045] p-7 shadow-2xl sm:p-10"><div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-2xl bg-[#9b5cff]/15"><ImagePlus className="size-6 text-[#c39aff]" /></span><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#35d7ff]">Fan gallery</p><h1 className="mt-1 text-3xl font-black tracking-tight">Submit fan art</h1></div></div><p className="mt-5 max-w-xl leading-7 text-white/55">Share photos, videos, or files with the Spearmacer1 community. You can choose multiple uploads at once, but at least one photo is required and you must be signed in.</p>{!isPending && !session?.user && <p className="mt-6 rounded-xl border border-[#f0b45c]/20 bg-[#f0b45c]/10 px-4 py-3 text-sm text-[#f7c983]">Please sign in before submitting fan art.</p>}<form onSubmit={submit} className="mt-8"><label htmlFor="fan-art-files" className="flex min-h-48 cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-white/20 bg-black/20 px-5 text-center transition hover:border-[#9b5cff]/60 hover:bg-[#9b5cff]/[0.06]"><FileUp className="size-8 text-[#b98aff]" /><span className="mt-3 font-bold">{files.length ? `${files.length} file${files.length === 1 ? '' : 's'} selected` : 'Choose photos or files'}</span><span className="mt-1 text-xs text-white/40">JPG, PNG, GIF, WEBP, MP4, WEBM, or PDF · 10 MB each</span><input id="fan-art-files" type="file" multiple accept="image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,application/pdf" className="sr-only" onChange={(event) => setFiles(Array.from(event.target.files ?? []))} /></label><div className="my-6 flex items-center gap-3 text-xs uppercase tracking-[.16em] text-white/30"><span className="h-px flex-1 bg-white/10" /> Or share a video link <span className="h-px flex-1 bg-white/10" /></div><label className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/20 px-4 py-3"><Link2 className="size-5 shrink-0 text-[#35d7ff]" /><input type="url" value={videoUrl} onChange={(event) => setVideoUrl(event.target.value)} placeholder="https://youtube.com/watch?v=..." className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-white/30" /></label><button disabled={isUploading} className="mt-5 inline-flex h-11 items-center gap-2 rounded-xl bg-[#934cff] px-5 text-sm font-bold transition hover:bg-[#a965ff] disabled:cursor-not-allowed disabled:opacity-50"><Upload className="size-4" /> {isUploading ? 'Uploading…' : 'Add to fan gallery'}</button>{status && <p className="mt-4 flex items-center gap-2 text-sm text-[#59e7a2]"><Check className="size-4" /> {status}</p>}</form></div></div></main>
}
