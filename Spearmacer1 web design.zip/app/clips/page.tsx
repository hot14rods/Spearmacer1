'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowLeft, Download, Film, Play, Upload } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

type Clip = { url: string; pathname: string; uploadedAt: string; size: number }

export default function ClipsPage() {
  const [tab, setTab] = useState<'upload' | 'browse'>('upload')
  const [file, setFile] = useState<File | null>(null)
  const [clips, setClips] = useState<Clip[]>([])
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const [uploadController, setUploadController] = useState<AbortController | null>(null)
  const { data: session } = authClient.useSession()

  async function browse() {
    setTab('browse')
    if (clips.length === 0) {
      const response = await fetch('/api/clips')
      const result = await response.json()
      setClips(result.clips ?? [])
    }
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!session?.user) return setStatus('Sign in to post a clip.')
    if (!file) return setStatus('Choose a video clip first.')
    setBusy(true); setStatus('')
    const data = new FormData(); data.append('file', file)
    const controller = new AbortController(); setUploadController(controller)
    let response: Response
    try { response = await fetch('/api/clips', { method: 'POST', body: data, signal: controller.signal }) } catch (error) { if (error instanceof DOMException && error.name === 'AbortError') { setBusy(false); setStatus('Upload canceled.'); setUploadController(null); return } throw error }
    const result = await response.json(); setUploadController(null)
    setBusy(false); setStatus(response.ok ? 'Your clip was posted successfully.' : result.error ?? 'Upload failed.')
    if (response.ok) { setFile(null); setTab('browse'); const updated = await fetch('/api/clips'); setClips((await updated.json()).clips ?? []) }
  }

  return <main className="min-h-screen bg-[#041321] px-5 py-8 text-[#f5f5f7] sm:px-8"><div className="mx-auto max-w-5xl"><Link href="/" className="inline-flex items-center gap-2 text-sm text-white/55 hover:text-white"><ArrowLeft className="size-4" /> Back home</Link><section className="mt-12 rounded-3xl border border-white/10 bg-[#071d31] p-7 sm:p-10"><div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-2xl bg-[#1677ad]/25"><Film className="size-6 text-[#67caff]" /></span><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#67caff]">Community clips</p><h1 className="mt-1 text-3xl font-black">Clips</h1></div></div><div className="mt-8 grid grid-cols-2 gap-2 rounded-2xl border border-white/10 bg-black/20 p-1"><button type="button" onClick={() => setTab('upload')} className={`rounded-xl px-4 py-3 text-sm font-bold transition ${tab === 'upload' ? 'bg-[#0d5b89] text-white' : 'text-white/50 hover:text-white'}`}><Upload className="mr-2 inline size-4" /> Upload a clip</button><button type="button" onClick={browse} className={`rounded-xl px-4 py-3 text-sm font-bold transition ${tab === 'browse' ? 'bg-[#0d5b89] text-white' : 'text-white/50 hover:text-white'}`}><Play className="mr-2 inline size-4" /> Browse clips</button></div>{tab === 'upload' ? <><p className="mt-5 leading-7 text-white/55">Share your best Minecraft moments with the kingdom.</p><form onSubmit={submit} className="mt-8"><label htmlFor="clip-file" className="flex min-h-48 cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-white/20 bg-black/20 text-center hover:border-[#3b9ed1]/60"><Upload className="size-8 text-[#67caff]" /><span className="mt-3 font-bold">{file ? file.name : 'Choose a video clip'}</span><span className="mt-1 text-xs text-white/40">MP4 or WEBM · 500 MB maximum · No length limit</span><input id="clip-file" type="file" accept="video/mp4,video/webm" className="sr-only" onChange={(event) => setFile(event.target.files?.[0] ?? null)} /></label><button type="submit" disabled={busy} className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-xl bg-[#1677ad] font-bold text-white disabled:opacity-50">{busy ? 'Posting...' : 'Post clip'}</button>{busy && <button type="button" onClick={() => uploadController?.abort()} className="ml-3 rounded-xl border border-[#ff8098]/30 px-5 py-3 text-sm font-bold text-[#ff9aae]">Cancel upload</button>}</form>{status && <p className="mt-5 text-sm text-white/70" role="status">{status}</p>}</> : <div className="mt-8">{clips.length === 0 ? <div className="rounded-2xl border border-dashed border-white/15 bg-black/15 p-12 text-center text-white/45">No clips have been posted yet.</div> : <div className="grid gap-5 md:grid-cols-2">{clips.map((clip) => <article key={clip.pathname} className="overflow-hidden rounded-2xl border border-white/10 bg-black/20"><video src={clip.url} controls className="aspect-video w-full bg-black" aria-label="Community clip" /><div className="flex items-center justify-between gap-3 p-4"><div><p className="text-sm font-bold">Community clip</p><p className="text-xs text-white/40">{new Date(clip.uploadedAt).toLocaleDateString()}</p></div><a href={clip.url} download className="rounded-lg border border-white/10 p-2 text-white/60 hover:bg-white/10 hover:text-white" aria-label="Download clip"><Download className="size-4" /></a></div></article>)}</div>}</div>}</section></div></main>
}
