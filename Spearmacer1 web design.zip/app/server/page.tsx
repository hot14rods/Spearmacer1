'use client'

import { useEffect, useState } from 'react'
import { ArrowLeft, Check, Copy, Gamepad2, LogIn, Search, UserPlus } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

const serverIp = 'spearmacercommmunity.mcsh.io'

export default function ServerPage() {
  const [copied, setCopied] = useState(false)
  const [whitelistRequested, setWhitelistRequested] = useState(false)
  const [minecraftUsername, setMinecraftUsername] = useState('')
  const [requestError, setRequestError] = useState('')
  const [ownerRequests, setOwnerRequests] = useState<Array<{ id: string; minecraftUsername: string; createdAt: string }>>([])
  const [isOwner, setIsOwner] = useState(false)
  const { data: session, isPending: sessionPending } = authClient.useSession()

  useEffect(() => {
    fetch('/api/whitelist').then(async (response) => {
      if (!response.ok) return
      const data = await response.json()
      setOwnerRequests(data.requests ?? [])
      setIsOwner(true)
    }).catch(() => undefined)
  }, [])

  async function copyIp() {
    await navigator.clipboard?.writeText(serverIp)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1800)
  }

  return (
    <main className="min-h-screen bg-[#101012] text-[#f5f5f7] selection:bg-[#9b5cff]/30">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,#251540_0%,transparent_48%),radial-gradient(ellipse_at_80%_20%,#073546_0%,transparent_34%)] opacity-60" />
      <div className="relative mx-auto max-w-5xl px-5 py-5 sm:px-8 lg:px-10">
        <header className="flex items-center justify-between border-b border-white/[0.08] pb-5">
          <a className="flex items-center gap-3" href="/" aria-label="Back to Spearmacer1 home">
            <span className="grid size-10 place-items-center rounded-xl border border-[#9b5cff]/40 bg-[#9b5cff]/10"><Gamepad2 className="size-5 text-[#bb8aff]" /></span>
            <span className="text-sm font-bold tracking-tight sm:text-base">Spearmacer1</span>
          </a>
          <a className="flex items-center gap-2 text-sm text-white/55 transition hover:text-white" href="/"><ArrowLeft className="size-4" /> Back home</a>
        </header>

        <section className="py-20 sm:py-28">
          <p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">Server hub</p>
          <h1 className="mt-3 max-w-3xl text-5xl font-black tracking-[-.05em] sm:text-7xl">Survival server.</h1>
          <p className="mt-6 max-w-xl text-lg leading-8 text-white/55">Build, explore, and make your mark in the Spearmacer1 community survival world.</p>

          <div className="mt-12 grid gap-5 md:grid-cols-[1.2fr_.8fr]">
            <div className="rounded-3xl border border-[#35d7ff]/20 bg-[#102630] p-7 sm:p-10">
              <div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-2xl bg-[#35d7ff]/10"><Gamepad2 className="size-6 text-[#35d7ff]" /></span><div><h2 className="text-xl font-bold">Survival</h2><p className="text-sm text-white/45">1.21.11 and up</p></div></div>
              <div className="mt-10"><p className="text-xs font-bold uppercase tracking-[.18em] text-white/40">Server IP</p><button type="button" onClick={copyIp} className="mt-3 flex w-full items-center justify-between rounded-2xl border border-white/10 bg-black/20 px-5 py-4 text-left font-mono text-sm text-[#8edfff] transition hover:border-[#35d7ff]/40"><span>{serverIp}</span>{copied ? <Check className="size-5 text-[#59e7a2]" /> : <Copy className="size-5 text-white/45" />}</button><p className="mt-3 text-sm text-white/45">Copy the address and join from Minecraft Multiplayer.</p></div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/[0.045] p-7 sm:p-8"><p className="text-xs font-bold uppercase tracking-[.18em] text-[#35d7ff]">Community note</p><h2 className="mt-4 text-2xl font-black">Be kind. Have fun.</h2><p className="mt-4 text-sm leading-7 text-white/50">Follow the community spirit, invite your friends, and help make every session a good one.</p></div>
          </div>

          <section className="mt-6 rounded-3xl border border-[#9b5cff]/20 bg-[#17131f]/85 p-7 sm:p-8" aria-labelledby="whitelist-heading">
            <div className="flex items-start gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-[#9b5cff]/10"><UserPlus className="size-5 text-[#bb8aff]" /></span>
              <div>
                <p className="text-xs font-bold uppercase tracking-[.18em] text-[#bb8aff]">Join the server</p>
                <h2 id="whitelist-heading" className="mt-2 text-2xl font-black">Add your Minecraft username</h2>
                <p className="mt-3 max-w-2xl text-sm leading-7 text-white/50">Enter your Minecraft username to get whitelisted on the server. Getting whitelisted could take up to 24 hours.</p>
              </div>
            </div>
            {whitelistRequested ? (
              <div className="mt-6 rounded-2xl border border-[#59e7a2]/20 bg-[#59e7a2]/10 px-5 py-4 text-sm text-[#a8f5ca]" role="status">Whitelist request received. Getting whitelisted could take up to 24 hours.</div>
            ) : sessionPending ? (
              <p className="mt-6 text-sm text-white/45">Checking your account...</p>
            ) : !session?.user ? (
              <div className="mt-6 flex flex-col gap-4 rounded-2xl border border-white/10 bg-black/20 p-5 sm:flex-row sm:items-center sm:justify-between">
                <p className="max-w-xl text-sm leading-6 text-white/55">Log in or create an account here to get whitelisted on the server.</p>
                <div className="flex flex-wrap gap-2"><a href="/sign-in" className="inline-flex h-11 items-center justify-center gap-2 rounded-2xl bg-[#9b5cff] px-5 text-sm font-bold text-white transition hover:bg-[#aa72ff]"><LogIn className="size-4" /> Log in</a><a href="/sign-up" className="inline-flex h-11 items-center justify-center rounded-2xl border border-white/15 px-5 text-sm font-bold text-white transition hover:border-white/30 hover:bg-white/5">Create account</a></div>
              </div>
            ) : (
              <form className="mt-6 flex flex-col gap-3 sm:flex-row" onSubmit={async (event) => { event.preventDefault(); setRequestError(''); const response = await fetch('/api/whitelist', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ minecraftUsername }) }); if (response.ok) setWhitelistRequested(true); else { const data = await response.json().catch(() => null); setRequestError(data?.error ?? 'Unable to request a whitelist.'); } }}>
                <label className="sr-only" htmlFor="minecraft-username">Minecraft username</label>
                <div className="relative flex-1">
                  <Search aria-hidden="true" className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-white/35" />
                  <input id="minecraft-username" name="minecraft-username" type="text" required maxLength={16} value={minecraftUsername} onChange={(event) => setMinecraftUsername(event.target.value)} placeholder="Your Minecraft username" className="h-12 w-full rounded-2xl border border-white/10 bg-black/20 pl-12 pr-4 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-[#9b5cff]/60 focus:ring-2 focus:ring-[#9b5cff]/20" />
                </div>
                <button type="submit" className="h-12 rounded-2xl bg-[#9b5cff] px-6 text-sm font-bold text-white transition hover:bg-[#aa72ff] focus:outline-none focus:ring-2 focus:ring-[#bb8aff]/60 focus:ring-offset-2 focus:ring-offset-[#101012]">Request whitelist</button>
                {requestError && <p className="text-sm text-red-300 sm:col-span-2" role="alert">{requestError}</p>}
              </form>
            )}
          {isOwner && <section className="mt-8 rounded-2xl border border-[#59e7a2]/20 bg-[#0d2018]/70 p-5" aria-labelledby="requests-heading"><p className="text-xs font-bold uppercase tracking-[.18em] text-[#59e7a2]">Owner only</p><h3 id="requests-heading" className="mt-2 text-xl font-bold">Whitelist requests</h3>{ownerRequests.length ? <ul className="mt-4 flex flex-col gap-2">{ownerRequests.map((request) => <li key={request.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm"><span className="font-mono text-white">{request.minecraftUsername}</span><span className="text-white/45">{new Date(request.createdAt).toLocaleDateString()}</span></li>)}</ul> : <p className="mt-4 text-sm text-white/50">No whitelist requests yet.</p>}</section>}
          </section>
        </section>
      </div>
    </main>
  )
}
