'use client'

import useSWR from 'swr'
import { useState } from 'react'
import type { ComponentType } from 'react'
import {
  ArrowUpRight,
  Check,
  Copy,
  ExternalLink,
  Heart,
  Gamepad2,
  LogIn,
  LogOut,
  MessageCircle,
  Play,
  ShieldCheck,
  Sparkles,
  Trash2,
  Trophy,
  User,
  Users,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { authClient } from '@/lib/auth-client'

type GalleryFile = { url: string; pathname: string; uploadedAt: string; contentType?: string }

function TwitchMark({ className }: { className?: string }) {
  return <svg aria-label="Twitch" className={className} viewBox="0 0 24 24" fill="currentColor" role="img"><path d="M4 3h17v12l-5 5h-4l-3 3v-3H4V3Z" /><path fill="white" d="M6 5v11h4v2l2-2h3.2l3.8-3.8V5H6Z" /><path fill="currentColor" d="M9 7h2v5H9V7Zm5 0h2v5h-2V7Z" /></svg>
}

function YoutubeMark({ className }: { className?: string }) {
  return <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-N7Wqm4VZn5kinEMcsPnKcxzIUjlOjM.png" alt="YouTube" className={`object-contain ${className ?? ''}`} />
}

  const socials = [
    { label: 'Twitch', handle: 'Watch live now', icon: TwitchMark, href: 'https://twitch.tv/ryderhotrodlive', className: 'hover:border-[#9147ff]/60 hover:bg-[#9147ff]/10', iconClass: 'text-[#a970ff]' },
    { label: 'YouTube', handle: 'Watch live now', icon: YoutubeMark, href: 'https://youtube.com/@Spearmacer1', className: 'hover:border-[#ff4b4b]/60 hover:bg-[#ff4b4b]/10', iconClass: 'text-[#ff5b5b]' },
  ]

export default function Page() {
  const [copied, setCopied] = useState(false)
  const [showDonatePopup, setShowDonatePopup] = useState(false)
  const { data: session } = authClient.useSession()
  const isOwner = session?.user?.email === 'hot14rods@gmail.com'
  const { data: statusData, mutate: mutateStatus } = useSWR<{ platform: 'offline' | 'youtube' | 'twitch' | 'multistream' }>('/api/site-status', (url) => fetch(url).then((response) => response.json()), { fallbackData: { platform: 'offline' } })
  const livePlatform = statusData?.platform ?? 'offline'
  const { data: clipData } = useSWR<{ clip?: { title: string; creator: string; views: number; url: string } }>('/api/twitch/clip-of-week', (url) => fetch(url).then((response) => response.json()), { refreshInterval: 900000 })
  const { data: galleryData, isLoading: galleryLoading } = useSWR<{ files?: GalleryFile[] }>('/api/fan-art', (url: string) => fetch(url).then((response) => response.json()))
  const weeklyClip = clipData?.clip
  const galleryFiles = galleryData?.files ?? []

  const liveLabel = livePlatform === 'offline' ? 'Offline' : livePlatform === 'multistream' ? 'Live now on Twitch and YouTube' : `Live now on ${livePlatform === 'youtube' ? 'YouTube' : 'Twitch'}`
  const liveUrl = livePlatform === 'twitch' ? 'https://twitch.tv/ryderhotrodlive' : 'https://youtube.com/@Spearmacer1'

  function copyServerIp() {
    navigator.clipboard?.writeText('spearmacercommmunity.mcsh.io')
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1800)
  }

  return (
<main className="min-h-screen overflow-hidden bg-[#041321] text-[#f5f5f7] selection:bg-[#35b9ff]/30">
  <div className="pointer-events-none fixed inset-0 -z-0 bg-[radial-gradient(ellipse_at_top,#0a294d_0%,transparent_48%),radial-gradient(ellipse_at_80%_20%,#075b86_0%,transparent_34%)] opacity-70" />
      <div className="relative z-10 mx-auto max-w-7xl px-5 py-5 sm:px-8 lg:px-10">
        <header className="flex items-center justify-between border-b border-white/[0.08] pb-5">
          <a className="flex items-center gap-3" href="#top" aria-label="Spearmacer1 home">
            <span className="grid size-10 place-items-center rounded-xl border border-[#9b5cff]/40 bg-[#9b5cff]/10 shadow-[0_0_24px_rgba(155,92,255,.18)]"><Gamepad2 className="size-5 text-[#bb8aff]" /></span>
            <span className="text-sm font-bold tracking-tight sm:text-base">Spearmacer1</span>
          </a>
          <nav className="hidden items-center gap-7 text-sm text-white/55 md:flex">
            <a className="transition hover:text-white" href="/fan-art">Fan gallery</a>
            <a className="transition hover:text-white" href="/clips">Post clips</a>
            <a className="transition hover:text-white" href="/schematics">Schematics</a>
            <a className="transition hover:text-white" href="/server">Server hub</a>
            <a className="transition hover:text-white" href="/community">Community</a>
          </nav>
          <div className="flex items-center gap-4">
<a href="https://youtube.com/@Spearmacer1" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm font-semibold text-[#d3b3ff] transition hover:text-white"><YoutubeMark className="size-4 text-[#ff5b5b]" /> Watch live now on YouTube <ExternalLink className="size-3.5" /></a>
  <a href="https://twitch.tv/ryderhotrodlive" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-sm font-semibold text-[#d3b3ff] transition hover:text-white"><TwitchMark className="size-4 text-[#a970ff]" /> Watch live now on Twitch <ExternalLink className="size-3.5" /></a>
            <AccountControls />
          </div>
        </header>

        <section id="top" className="grid gap-10 pb-16 pt-16 lg:grid-cols-[1.1fr_.9fr] lg:items-end lg:pt-24">
          <div>
            <div className={`mb-7 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-bold uppercase tracking-[0.18em] ${livePlatform === 'offline' ? 'border-white/15 bg-white/[0.06] text-white/60' : 'border-[#ff5577]/25 bg-[#ff5577]/[0.08] text-[#ff8098]'}`}><span className={`size-1.5 rounded-full ${livePlatform === 'offline' ? 'bg-white/40' : 'animate-pulse bg-[#ff5577]'}`} /> {liveLabel} <span className="font-normal tracking-normal text-white/40">· Pvp and Donut smp</span></div>
            <h1 className="max-w-3xl text-5xl font-black leading-[.95] tracking-[-.06em] sm:text-7xl">Welcome to the<br /><span className="bg-gradient-to-r from-[#c38bff] via-[#8d7aff] to-[#35d7ff] bg-clip-text text-transparent">Fan Kingdom.</span></h1>
            <p className="mt-7 max-w-xl text-base leading-7 text-white/55 sm:text-lg">A home for the builders, dreamers, and absolute legends who make the Spearmacer1 community what it is.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-[#934cff] px-5 text-sm font-bold text-white shadow-[0_0_30px_rgba(147,76,255,.28)] transition hover:bg-[#a965ff]" href={liveUrl} target="_blank" rel="noreferrer"><Play className="size-4 fill-current" /> {livePlatform === 'offline' ? 'Watch replay' : 'Watch live'}</a>
              <a className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/[0.04] px-5 text-sm font-medium text-white transition hover:bg-white/10" href="/server">Explore the server <ArrowUpRight className="size-4" /></a>
            </div>
            {isOwner && (
              <div className="mt-5 flex flex-wrap items-center gap-2 text-xs text-white/45">
                <span>Manual status:</span>
                {(['youtube', 'twitch', 'multistream', 'offline'] as const).map((platform) => <button key={platform} type="button" onClick={async () => {
                    const response = await fetch('/api/site-status', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ platform }) })
                    if (response.ok) await mutateStatus()
                  }} className={`rounded-lg border px-3 py-1.5 font-semibold capitalize transition ${livePlatform === platform ? 'border-[#35d7ff]/50 bg-[#35d7ff]/10 text-[#8edfff]' : 'border-white/10 bg-white/[0.03] text-white/55 hover:bg-white/[0.08]'}`}>{platform === 'offline' ? 'Offline' : platform === 'multistream' ? 'Live on Twitch + YouTube' : `Live on ${platform === 'youtube' ? 'YouTube' : 'Twitch'}`}</button>)}
              </div>
            )}
          </div>
          <div className="relative rounded-3xl border border-white/10 bg-white/[0.045] p-6 shadow-2xl backdrop-blur-sm sm:p-8">
            <div className="absolute -right-16 -top-16 size-40 rounded-full bg-[#35d7ff]/10 blur-3xl" />
            <div className="flex items-center justify-between"><div className="flex items-center gap-3"><div className="grid size-12 place-items-center rounded-2xl bg-gradient-to-br from-[#934cff] to-[#35d7ff] text-lg font-black">S1</div><div><p className="font-bold">Spearmacer1</p><p className="text-xs text-white/45">Minecraft creator · 2026–present</p></div></div><span className="rounded-md bg-[#31d08a]/10 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-[#59e7a2]">Online</span></div>
            <div className="my-7 h-px bg-white/[0.08]" />
            <div className="flex items-end justify-between"><div><p className="text-4xl font-black tracking-tight">153</p><p className="mt-1 text-xs text-white/45">Total Followers/Subscribers</p></div><Trophy className="mb-2 size-7 text-[#ffd166]" /></div>
            <div className="mt-6 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full w-[77%] rounded-full bg-gradient-to-r from-[#934cff] to-[#35d7ff] shadow-[0_0_12px_#35d7ff]" /></div><div className="mt-2 flex justify-between text-xs text-white/45"><span>Road to 200</span><span className="font-semibold text-[#8edfff]">77% complete</span></div><p className="mt-4 text-sm text-white/60">Follow on Twitch or subscribe on YouTube to join the counter. Updates daily.</p>
          </div>
        </section>

        <section className="grid gap-5 border-y border-white/[0.08] py-7 sm:grid-cols-3"><Stat icon={TwitchMark} value="38" label="Twitch followers" /><Stat icon={YoutubeMark} value="115" label="YouTube subscribers" /><Stat icon={Sparkles} value="#1" label="Community server" /></section>

        <section id="gallery" className="py-16"><SectionHeading eyebrow="From the community" title="Built by legends." action="Submit fan art" actionHref="/fan-art/submit" />{galleryLoading ? <p className="text-sm text-white/45">Loading community uploads...</p> : galleryFiles.length === 0 ? <div className="rounded-3xl border border-dashed border-white/15 bg-white/[0.03] p-10 text-center"><p className="text-sm text-white/50">No fan art has been uploaded yet.</p><a href="/fan-art/submit" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#934cff] px-5 py-3 text-sm font-bold transition hover:bg-[#a965ff]">Be the first to upload fan art <ArrowUpRight className="size-4" /></a></div> : <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{galleryFiles.slice(0, 4).map((file) => <article key={file.pathname} className="group overflow-hidden rounded-2xl border border-white/10 bg-white/[0.045]"><div className="flex aspect-[4/3] items-center justify-center bg-black/20">{file.contentType?.startsWith('image/') ? <img src={file.url} alt="Community fan art upload" className="size-full object-contain bg-black/20 transition duration-300 group-hover:scale-105" /> : file.contentType?.startsWith('video/') ? <video src={file.url} controls className="size-full object-cover" aria-label="Community fan video" /> : <a href={file.url} target="_blank" rel="noreferrer" className="p-5 text-center text-sm text-[#8edfff] underline">Open shared video link</a>}</div><p className="px-4 py-3 text-xs text-white/50">Uploaded community fan art</p></article>)}</div>}</section>

        <section className="grid gap-5 pb-16 lg:grid-cols-[1.25fr_.75fr]"><div className="relative overflow-hidden rounded-3xl border border-[#35d7ff]/20 bg-[#102630] p-7 sm:p-10"><div className="absolute -right-20 -top-20 size-64 rounded-full bg-[#35d7ff]/10 blur-3xl" /><div className="relative"><div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[.18em] text-[#6be4ff]"><Play className="size-3.5 fill-current" /> Clip of the week</div><h2 className="mt-5 max-w-md text-3xl font-black tracking-tight">“{weeklyClip?.title ?? 'The most-viewed clip from Ryderhotrodlive'}”</h2><p className="mt-3 text-sm text-white/50">{weeklyClip ? `Captured by @${weeklyClip.creator} · ${weeklyClip.views.toLocaleString()} views` : 'Checking the Ryderhotrodlive channel for the top clip...'}</p><a href={weeklyClip?.url ?? 'https://twitch.tv/ryderhotrodlive'} target="_blank" rel="noreferrer" className="mt-8 inline-flex h-10 items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 text-sm font-medium text-white transition hover:bg-white/10">Watch clip <ArrowUpRight /></a></div><a href={weeklyClip?.url ?? 'https://twitch.tv/ryderhotrodlive'} target="_blank" rel="noreferrer" aria-label="Play the most-viewed Twitch clip" className="absolute bottom-7 right-7 grid size-24 place-items-center rounded-full border border-white/20 bg-black/20 backdrop-blur transition hover:scale-105 hover:bg-black/30 sm:size-32"><span className="grid size-12 place-items-center rounded-full bg-white text-black sm:size-16"><Play className="size-5 fill-current sm:size-6" /></span></a></div><div id="server" className="rounded-3xl border border-white/10 bg-[#19191e] p-7 sm:p-8"><div className="flex items-center justify-between"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-[#35d7ff]/10"><Gamepad2 className="size-5 text-[#35d7ff]" /></span><div><h2 className="font-bold">Survival server</h2><p className="text-xs text-white/45">Survival · 1.21.11 and up</p></div></div></div><button onClick={copyServerIp} className="mt-7 flex w-full items-center justify-between rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-left transition hover:border-[#35d7ff]/50"><span><span className="block text-[10px] uppercase tracking-wider text-white/40">Server IP</span><span className="font-mono text-sm text-[#a9edff]">spearmacercommmunity.mcsh.io</span></span>{copied ? <Check className="size-4 text-[#59e7a2]" /> : <Copy className="size-4 text-white/45" />}</button><div className="mt-5 flex gap-3 text-xs text-white/50"><ShieldCheck className="size-4 shrink-0 text-[#ffd166]" /><p>Be kind, have fun.<br /><span className="text-white/30">Be kind, have fun.</span></p></div></div></section>

        <section id="community" className="border-t border-white/[0.08] py-10"><div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">Stay connected</p><h2 className="mt-2 text-2xl font-black tracking-tight">Find your people.</h2></div><div className="grid w-full gap-3 sm:w-auto sm:grid-cols-3">{socials.map(({ label, handle, icon: Icon, href, className, iconClass }) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={`Open ${label}`} className={`flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 transition ${className}`}><Icon className={`size-5 ${iconClass}`} /><span><span className="block text-sm font-bold">{label}</span><span className="block text-[11px] text-white/40">{handle}</span></span></a>)}<button type="button" onClick={() => setShowDonatePopup(true)} className="flex items-center gap-3 rounded-xl border border-[#ff5577]/25 bg-[#ff5577]/[0.06] px-4 py-3 text-left transition hover:border-[#ff5577]/60 hover:bg-[#ff5577]/10" aria-label="Donate while live"><Heart className="size-5 fill-[#ff5577] text-[#ff8098]" /><span><span className="block text-sm font-bold">Donate while live</span><span className="block text-[11px] text-white/40">Support the stream</span></span></button></div></div>{showDonatePopup && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 px-5 backdrop-blur-sm" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowDonatePopup(false) }}><section role="dialog" aria-modal="true" aria-labelledby="donate-title" className="w-full max-w-md rounded-3xl border border-[#ff5577]/25 bg-[#19191e] p-7 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#ff8098]">Stay connected</p><h2 id="donate-title" className="mt-2 text-2xl font-black">Support the stream</h2></div><button type="button" onClick={() => setShowDonatePopup(false)} className="grid size-9 place-items-center rounded-xl border border-white/10 text-white/55 transition hover:bg-white/10 hover:text-white" aria-label="Close donation dialog"><X className="size-4" /></button></div><p className="mt-4 text-sm leading-6 text-white/55">Thanks for supporting Ryderhotrodlive. Your donation helps keep the streams going and gives an on-screen pop-out for donations of $1 or more.</p><a href="https://streamlabs.com/ryderhotrodlive/tip" target="_blank" rel="noopener noreferrer" className="mt-7 inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#ff5577] text-sm font-bold text-white transition hover:bg-[#ff6d8a]">Donate while live <ExternalLink className="size-4" /></a></section></div>}<footer className="mt-14 flex flex-col gap-2 text-xs text-white/30 sm:flex-row sm:items-center sm:justify-between"><span>© 2026 Spearmacer1.</span><span>Keep building. Keep adventuring.</span></footer></section>
      </div>
    </main>
  )
}

function AccountControls() {
  const { data: session, isPending } = authClient.useSession()
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [deleteError, setDeleteError] = useState('')
  const [isDeleting, setIsDeleting] = useState(false)
  const [showPasswordChange, setShowPasswordChange] = useState(false)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [passwordMessage, setPasswordMessage] = useState('')
  const [isChangingPassword, setIsChangingPassword] = useState(false)
  const [showRecovery, setShowRecovery] = useState(false)
  const [backups, setBackups] = useState<Array<{ id: string; email: string; name: string; deletedAt: string }>>([])
  const [showAccountMenu, setShowAccountMenu] = useState(false)

  if (isPending) return null
  if (!session?.user) return <a href="/sign-in" className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/70 transition hover:bg-white/10 hover:text-white"><LogIn className="size-4" /> Account</a>

  const isOwner = session.user.email === 'hot14rods@gmail.com'
  async function openRecovery() {
    const response = await fetch('/api/account/recovery')
    if (response.ok) { const data = await response.json(); setBackups(data.backups ?? []); setShowRecovery(true) }
  }
  async function restoreAccount(backupId: string) {
    const response = await fetch('/api/account/recovery', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ backupId }) })
    if (response.ok) setBackups((items) => items.filter((item) => item.id !== backupId))
  }
  async function changePassword() {
    setIsChangingPassword(true)
    setPasswordMessage('')
    const result = await authClient.changePassword({ currentPassword, newPassword, revokeOtherSessions: true })
    if (result.error) setPasswordMessage('The old password was incorrect or the new password is invalid.')
    else { setPasswordMessage('Password changed successfully.'); setCurrentPassword(''); setNewPassword('') }
    setIsChangingPassword(false)
  }
  async function deleteAccount() {
    setIsDeleting(true)
    setDeleteError('')
    const response = await fetch('/api/account/delete', { method: 'POST' })
    if (!response.ok) {
      setDeleteError('We could not delete your account. Please try again.')
      setIsDeleting(false)
      return
    }
    window.location.href = '/'
  }

  return <>
    <div className="relative"><button type="button" onClick={() => setShowAccountMenu((open) => !open)} className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/70 transition hover:bg-white/10 hover:text-white"><User className="size-4" /> Account</button>{showAccountMenu && <div className="absolute right-0 top-12 z-40 flex min-w-56 flex-col gap-2 rounded-2xl border border-white/10 bg-[#19191e] p-3 shadow-2xl"><p className="px-2 text-xs text-white/45">{isOwner ? 'Owner' : session.user.name}</p><button type="button" onClick={() => setShowPasswordChange(true)} className="rounded-xl px-3 py-2 text-left text-xs font-semibold text-white/70 hover:bg-white/10 hover:text-white">Change password</button><button type="button" onClick={() => authClient.signOut().then(() => window.location.reload())} className="rounded-xl px-3 py-2 text-left text-xs font-semibold text-white/70 hover:bg-white/10 hover:text-white">Sign out</button></div>}</div><div className="hidden"> <span className="hidden text-xs text-white/50 sm:inline">{isOwner ? 'Owner' : session.user.name}</span><button type="button" onClick={() => authClient.signOut().then(() => window.location.reload())} className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/70 transition hover:bg-white/10 hover:text-white"><LogOut className="size-4" /> Sign out</button>{isOwner && <button type="button" onClick={openRecovery} className="rounded-xl border border-[#59e7a2]/25 bg-[#59e7a2]/[0.06] px-3 py-2 text-xs font-semibold text-[#a8f5ca] transition hover:bg-[#59e7a2]/10">Recover accounts</button>}<button type="button" onClick={() => setShowPasswordChange(true)} className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs font-semibold text-white/70 transition hover:bg-white/10 hover:text-white">Change password</button><button type="button" onClick={() => setShowDeleteConfirm(true)} className="grid size-9 place-items-center rounded-xl border border-[#ff5577]/20 bg-[#ff5577]/[0.06] text-[#ff8098] transition hover:border-[#ff5577]/50 hover:bg-[#ff5577]/10" aria-label="Delete account"><Trash2 className="size-4" /></button></div>
    {showRecovery && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 px-5 backdrop-blur-sm" role="presentation"><section role="dialog" aria-modal="true" aria-labelledby="recovery-title" className="w-full max-w-lg rounded-3xl border border-white/10 bg-[#19191e] p-7 shadow-2xl"><h2 id="recovery-title" className="text-2xl font-black">Deleted account recovery</h2><p className="mt-3 text-sm text-white/55">These accounts can be restored if someone deleted theirs accidentally while you were streaming.</p><div className="mt-6 flex flex-col gap-2">{backups.length ? backups.map((backup) => <div key={backup.id} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-black/20 p-3"><div><p className="text-sm font-bold">{backup.name}</p><p className="text-xs text-white/45">{backup.email}</p></div><button type="button" onClick={() => restoreAccount(backup.id)} className="rounded-lg bg-[#59e7a2] px-3 py-2 text-xs font-bold text-black">Restore</button></div>) : <p className="text-sm text-white/45">No deleted accounts are waiting for recovery.</p>}</div><button type="button" onClick={() => setShowRecovery(false)} className="mt-6 rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold text-white/70">Close</button></section></div>}
    {showPasswordChange && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 px-5 backdrop-blur-sm" role="presentation"><section role="dialog" aria-modal="true" aria-labelledby="change-password-title" className="w-full max-w-md rounded-3xl border border-white/10 bg-[#19191e] p-7 shadow-2xl"><h2 id="change-password-title" className="text-2xl font-black">Change password</h2><p className="mt-3 text-sm text-white/55">Enter your old password to confirm this change.</p><div className="mt-6 flex flex-col gap-3"><label className="text-sm font-semibold">Old password<input type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} required className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 outline-none focus:border-[#35d7ff]/60" /></label><label className="text-sm font-semibold">New password<input type="password" minLength={8} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} required className="mt-2 h-11 w-full rounded-xl border border-white/10 bg-black/20 px-3 outline-none focus:border-[#35d7ff]/60" /></label></div>{passwordMessage && <p className="mt-4 text-sm text-white/70" role="status">{passwordMessage}</p>}<div className="mt-7 flex justify-end gap-3"><button type="button" onClick={() => setShowPasswordChange(false)} className="rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold text-white/70">Cancel</button><button type="button" onClick={changePassword} disabled={isChangingPassword || !currentPassword || !newPassword} className="rounded-xl bg-[#35d7ff] px-4 py-2.5 text-sm font-bold text-black disabled:opacity-50">{isChangingPassword ? 'Changing...' : 'Change password'}</button></div></section></div>}
    {showDeleteConfirm && <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 px-5 backdrop-blur-sm" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowDeleteConfirm(false) }}><section role="dialog" aria-modal="true" aria-labelledby="delete-account-title" className="w-full max-w-md rounded-3xl border border-white/10 bg-[#19191e] p-7 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#ff8098]">Account settings</p><h2 id="delete-account-title" className="mt-2 text-2xl font-black">Delete your account?</h2></div><button type="button" onClick={() => setShowDeleteConfirm(false)} className="grid size-9 place-items-center rounded-xl border border-white/10 text-white/55 transition hover:bg-white/10 hover:text-white" aria-label="Close delete account dialog"><X className="size-4" /></button></div><p className="mt-4 text-sm leading-6 text-white/55">This permanently removes your account and cannot be undone.</p>{deleteError && <p className="mt-4 rounded-xl border border-[#ff5577]/25 bg-[#ff5577]/10 px-3 py-2 text-sm text-[#ff9aae]" role="alert">{deleteError}</p>}<div className="mt-7 flex justify-end gap-3"><button type="button" onClick={() => setShowDeleteConfirm(false)} className="rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold text-white/70 transition hover:bg-white/10 hover:text-white">Cancel</button><button type="button" onClick={deleteAccount} disabled={isDeleting} className="rounded-xl bg-[#e54868] px-4 py-2.5 text-sm font-bold text-white transition hover:bg-[#f05c79] disabled:cursor-not-allowed disabled:opacity-60">{isDeleting ? 'Deleting...' : 'Delete account'}</button></div></section></div>}
  </>
}

function Stat({ icon: Icon, value, label }: { icon: ComponentType<{ className?: string }>; value: string; label: string }) { return <div className="flex items-center gap-3"><Icon className="size-5 text-[#9b7aff]" /><div><p className="font-bold">{value}</p><p className="text-xs text-white/40">{label}</p></div></div> }
function SectionHeading({ eyebrow, title, action, actionHref }: { eyebrow: string; title: string; action: string; actionHref: string }) { return <div className="mb-7 flex items-end justify-between"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-[#35d7ff]">{eyebrow}</p><h2 className="mt-2 text-3xl font-black tracking-tight">{title}</h2></div><a href={actionHref} className="hidden items-center gap-1 text-sm font-semibold text-white/55 transition hover:text-white sm:flex">{action} <ArrowUpRight className="size-4" /></a></div> }
